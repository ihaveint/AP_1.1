import menus.FullSizeFrame;
import menus.FullSizePanel;
import menus.GameFrame;
import menus.LoadPanel;
import resources.GlobalHashMap;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        GameFrame main_window = GameFrame.getInstance();
        LoadBeforeRun.getInstance();
        main_window.start();

    }
}
