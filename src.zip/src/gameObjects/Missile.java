package gameObjects;

public class Missile extends shoot{

    public Missile(int x, int y) {

        super(x, y);
        type = "Missile";
    }

}
