package resources;

public class Location {
    public double x , y;
    public Location(){

    }
    public Location(int x , int y){
        this.x = x;
        this.y  = y;
    }
    public Location(double x , double y){
        this.x = x;
        this.y = y;
    }

}
